
$( document ).ready(function() {
	
			function getInterestRates( $obj ){ 
				var account = "";
				if ($obj.val() !== "" && $obj.val() === 'fixed') {
					account = '1,0.06|2,0.06|3,0.06|6,0.075|9,0.0775|12,0.0805';
				}
				if ($obj.val() !== "" && $obj.val() === 'saving') {
					account = '1,0.06|2,0.06|3,0.06|4,0.06|5,0.06|6,0.06|7,0.06|8,0.06|9,0.06|10,0.06|11,0.06|12,0.06';
				}
				var rates = account.split("|");
				var rate_list = [];
				for (var i = 0; i < rates.length; i++) {
					rate_list.push(rates[i].split(","));
				}
				return rate_list; 
			}
			/* apply period month based on account selection */
			$(".interest-cal #account").change(function (e) {
				e.preventDefault();
				var $result_wrap = $(".interest-cal .result .wrap");
				var $rate_wrap = $(".interest-cal .wrap.rate");
				$result_wrap.hide();
				$rate_wrap.hide();
				var rate_list = getInterestRates( $(this) ); 
				var output = '<option value="">- Months to Grow -</option>';
				for (var i = 0; i < rate_list.length; i++) {
					output += '<option value="' + rate_list[i][0] + '">';
					output += rate_list[i][0] + ' month';
					output += (rate_list[i][0] > 1) ? 's' : '';
					output += '</option>';
					//  output +=
				}
				$(".interest-cal #period").html(output);
			})
			//when calculate button is clicked
			$(".interest-cal form").submit(function (e) {
				e.preventDefault();
				$("input, select").removeClass('error');
				var $wrap = $(".interest-cal .result .wrap");
				var $account = $(".interest-cal #account");
				var $amount = $(".interest-cal #amount");
				var $period = $(".interest-cal #period"); 
				var amount = $amount.val();
				var period = $period.val();
				var day_count = 365;
				
				var isValid = true;
				if (amount === "" || amount % 1 !== 0 || amount === "0") {
					$amount.addClass('error');
					isValid = false;
				}
				if (period === "") {
					$period.addClass('error');
					isValid = false;
				}
				if (isValid) {
					var rate_list = getInterestRates( $account );
					for (var i = 0; i < rate_list.length; i++) {
						if (rate_list[i][0] == period) {

							// to cound days
							if(period==12){
								period = day_count;
							}else{
								period = (period * 30); 
							}

							//int_amount = (amount * rate_list[i][1]) / 365;
							int_amount = amount * rate_list[i][1];
							int_amount = (int_amount * period)/365;                    
							int_amount = int_amount.toFixed(2);
						}
					}
					if (period === "") {
						$wrap.hide();
					} else {
						$(".interest-cal #total-interest").html(int_amount);
						$wrap.show();
					}
				}
			});
			//when the period select is changed
			$(".interest-cal #period").change(function (e) {
				e.preventDefault();
				var period = $(this).val();
				var $wrap = $(".interest-cal .wrap.rate");
				var $account = $(".interest-cal #account");
				var account = "";
				var rate_list = getInterestRates( $account );
				var int_rate = 0;
				for (var i = 0; i < rate_list.length; i++) {
					if (rate_list[i][0] == period) {
						int_rate = rate_list[i][1] * 100;
					}
				}
				if (period === "") {
					$wrap.hide();
					$(".interest-cal .result .wrap").hide();
				} else {
					$(".interest-cal #interest-rate").html(int_rate);
					$wrap.show();
				}
			})
			$(".interest-cal input[type=reset]").click(function(e){
				var $wrap_result = $(".interest-cal .result .wrap");
				var $wrap_rate = $(".interest-cal .wrap.rate");
				$wrap_result.hide();
				$wrap_rate.hide();
			});
	}); 

window.addEventListener('DOMContentLoaded', event => {

    // Activate Bootstrap scrollspy on the main nav element
    const mainNav = document.body.querySelector('#mainNav');
    if (mainNav) {
        new bootstrap.ScrollSpy(document.body, {
            target: '#mainNav',
            offset: 74,
        });
    };

    // Collapse responsive navbar when toggler is visible
    const navbarToggler = document.body.querySelector('.navbar-toggler');
    const responsiveNavItems = [].slice.call(
        document.querySelectorAll('#navbarResponsive .nav-link')
    );
    responsiveNavItems.map(function (responsiveNavItem) {
        responsiveNavItem.addEventListener('click', () => {
            if (window.getComputedStyle(navbarToggler).display !== 'none') {
                navbarToggler.click();
            }
        });
    });

});
